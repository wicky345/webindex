<template>
<div>
 <button @click="spackage()">查找</button> 

</div>
</template>
<script>
    export default {
        data(){
            return{
       pname:'ox-cli',
       html:`<html lang="en-us"><head>
    <meta charset="utf-8">
    <title>Sinopia</title>

    <link rel="icon" type="image/png" href="http://10.199.201.17:4873/-/static/favicon.png">
    <link rel="stylesheet" type="text/css" href="http://10.199.201.17:4873/-/static/main.css">
    <meta name="viewport" content="width=device-width, initial-scale=1">
  </head>
  <body class="body">
    <header class="main-header">
      <nav class="navbar navbar-default red-bg white no-border no-rnd-cnr" role="navigation">
        <div class="container">
          <div class="navbar-header clearfix">
            <div class="npm-logo brand">
              <a href="http://10.199.201.17:4873"></a>
            </div>

            <!-- login/logout for small devices -->
            <div class="pull-right visible-xs pad-right-10">
              <div>
                <p class="white no-bg navbar-text pad-right-10 inline-block">&nbsp;</p>
                <button type="submit" class="btn btn-danger inline-block" data-toggle="modal" data-target="#login-form" onclick="return false">Login</button>
              </div>
            </div>
          </div>

          <div class="navbar-left hidden-xs">&nbsp;&nbsp;</div>

          <div class="navbar-left setup hidden-xs">
            <code class="white no-bg">npm set registry http://10.199.201.17:4873</code><br>
            <code class="white no-bg">npm adduser --registry http://10.199.201.17:4873</code>
          </div>

          <!-- login/logout for large devices -->
          <div class="navbar-collapse collapse">
            <div class="navbar-right">
              <form class="navbar-form navbar-right">
                <button type="submit" class="btn btn-danger inline-block" data-toggle="modal" data-target="#login-form" onclick="return false">Login</button>
              </form>
            </div>
          </div>


        </div>
      </nav>
      <header class="sm-registry-info light-red-bg center hidden-sm hidden-lg hidden-md">
        <code class="white no-bg">http://10.199.201.17:4873</code><br>
      </header>
      <header class="packages-header container">
        <div class="row">
          <div class="col-md-5 hidden-xs hidden-sm">
            <h2 class="title">Available Packages</h2>
          </div>
          <div class="col-md-4 col-md-offset-3 col-sm-12">
            <form id="search-form">
              <div class="input-group input-group-lg search-container">
                <input type="text" class="form-control" placeholder="Search for packages">
                <span class="input-group-btn">
                  <button class="btn btn-default search-icon js-search-btn"><i class="icon-search"></i></button>
                </span>
              </div>
            </form>
          </div>
        </div>
      </header>
    </header>

    <section class="content container packages-container" id="all-packages">
          <div class="entry" data-name="sp-address" data-version="1.0.0">
            <div class="row">
              <div class="col-md-8 col-sm-8">
                <h4 class="title">
                  <a class="name icon-angle-right red" href="javascript:void(0)">sp-address</a>
                  <small class="version">v1.0.0</small>
                </h4>
              </div>
              <div class="col-md-4 col-sm-4">
                <div class="author pull-right">
                  <small>By: </small>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-12">
                <p class="description">An Angular address plugin</p>
              </div>
            </div>
          </div>
          <div class="entry" data-name="pjui" data-version="1.0.2">
            <div class="row">
              <div class="col-md-8 col-sm-8">
                <h4 class="title">
                  <a class="name icon-angle-right red" href="javascript:void(0)">pjui</a>
                  <small class="version">v1.0.2</small>
                </h4>
              </div>
              <div class="col-md-4 col-sm-4">
                <div class="author pull-right">
                  <small>By: admin</small>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-12">
                <p class="description">Component library based on iview</p>
              </div>
            </div>
          </div>
          <div class="entry" data-name="ox-cli" data-version="1.0.62">
            <div class="row">
              <div class="col-md-8 col-sm-8">
                <h4 class="title">
                  <a class="name icon-angle-right red" href="javascript:void(0)">ox-cli</a>
                  <small class="version">v1.0.62</small>
                </h4>
              </div>
              <div class="col-md-4 col-sm-4">
                <div class="author pull-right">
                  <small>By: admin</small>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-12">
                <p class="description">A simple CLI for scaffolding Vue.js projects.</p>
              </div>
            </div>
          </div>
          <div class="entry" data-name="element-ui-test" data-version="2.4.0">
            <div class="row">
              <div class="col-md-8 col-sm-8">
                <h4 class="title">
                  <a class="name icon-angle-right red" href="javascript:void(0)">element-ui-test</a>
                  <small class="version">v2.4.0</small>
                </h4>
              </div>
              <div class="col-md-4 col-sm-4">
                <div class="author pull-right">
                  <small>By: admin</small>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-12">
                <p class="description">A Component Library for Vue.js.</p>
              </div>
            </div>
          </div>
          <div class="entry" data-name="ox-ui" data-version="0.2.5">
            <div class="row">
              <div class="col-md-8 col-sm-8">
                <h4 class="title">
                  <a class="name icon-angle-right red" href="javascript:void(0)">ox-ui</a>
                  <small class="version">v0.2.5</small>
                </h4>
              </div>
              <div class="col-md-4 col-sm-4">
                <div class="author pull-right">
                  <small>By: </small>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-12">
                <p class="description">Vue components for PJBest</p>
              </div>
            </div>
          </div>

    </section>

    <section class="content container pkg-search-container" id="search-results"></section>

    <div class="modal fade" id="login-form" tabindex="-1" role="dialog" aria-labelledby="login-form-label" aria-hidden="true">
      <div class="modal-dialog modal-sm">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span><span class="sr-only">Close</span></button>
            <h5 class="modal-title" id="login-form-label">Welcome back</h5>
          </div>
          <form role="form" action="http://10.199.201.17:4873/-/login" method="post" id="login-form" autocomplete="off">
            <div class="modal-body">
              <div class="form-group">
                <label for="user" class="sr-only">Email</label>
                <input name="user" id="user" class="form-control" placeholder="Username" type="text">
              </div>
              <div class="form-group">
                <label for="pass" class="sr-only">Password</label>
                <input name="pass" id="pass" class="form-control" placeholder="Password" type="password">
              </div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
              <button type="submit" class="btn btn-primary">Log in</button>
            </div>
          </form>
        </div>
      </div>
    </div>

    <form action="http://10.199.201.17:4873/-/logout" method="post" class="hide" id="userLogoutForm"></form>
</body></html>`
            }
        },
        methods: {
    spackage(){
       var smsg=new RegExp(this.pname+'\" data-version=\"(\\d+.*)+');
        var climsg=this.html.match(smsg);
        
       var msg= climsg[0].match(/\d+.\d+.\d+/gi);
      alert(msg);
    }
  }
        }
</script>